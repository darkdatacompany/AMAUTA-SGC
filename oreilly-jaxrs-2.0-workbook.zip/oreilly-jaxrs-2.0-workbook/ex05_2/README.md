Injection Annotations
=====================
This project is a simple example showing usage of JAX-RS injection annotations.

System Requirements:
-------------------------
- Maven 2.0.9 or higher

Building the project:
-------------------------
1. In root directoy

mvn jetty:run

This will build a WAR and run it with embedded Jetty

Then open browser and go to:

http://localhost:8080

Submit form and follow links.
