@Path expressions
========================
Shows simple example of using @Path with regular expressions.

System Requirements:
-------------------------
- Maven 3.0.4 or higher

Building the project:
-------------------------
1. In root directory

mvn clean install

This will build a WAR and run it with embedded Jetty