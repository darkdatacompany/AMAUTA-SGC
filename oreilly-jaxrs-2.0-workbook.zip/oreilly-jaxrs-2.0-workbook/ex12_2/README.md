WriterInterceptor
========================
This project implements a WriterInterceptor that generates a Content-MD5 header hash of the message body.

System Requirements:
-------------------------
- Maven 3.0.4 or higher

Building the project:
-------------------------
1. In root directory

mvn clean install

This will build a WAR and run it with embedded Jetty