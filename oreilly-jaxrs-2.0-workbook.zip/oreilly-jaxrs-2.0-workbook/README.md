RESTful Java with JAX-RS 2.0 Workbook
=========================
The examples in this directory are a compliment to the O'Reilly "RESTful Java with JAX-RS 2.0" book.  This book has
a detailed explanation of REST and JAX-RS.  The appendix of the book also walks through all the example code provided within
this directory.

You can buy this book at:

http://oreilly.com/catalog/ ... need to add this ...

The author, Bill Burke, is the founder of the RESTEasy project.




